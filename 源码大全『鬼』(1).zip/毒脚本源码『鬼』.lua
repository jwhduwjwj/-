game:GetService("StarterGui"):SetCore("SendNotification",{ Title = "成功进入"; Text ="毒·脚本"; Duration = 4; })
local OrionLib = loadstring(game:HttpGet('https://pastebin.com/raw/xLRUSiKx'))()
local Window = OrionLib:MakeWindow({Name = "毒·脚本", HidePremium = false, SaveConfig = true,IntroText = "毒·脚本", ConfigFolder = "毒·脚本"})
game:GetService("StarterGui"):SetCore("SendNotification",{ Title = "欢迎，此为私人订制不可贩卖"; Text ="脚本"; Duration = 4; })
local about = Window:MakeTab({
    Name = "你好",
    Icon = "rbxassetid://7734068321",
    PremiumOnly = false
})
about:AddParagraph("你看你妈呢")
local Tab = Window:MakeTab({
    Name = "力量传奇",
    	Icon = "rbxassetid://4483345998",
    		PremiumOnly = false})
Tab:AddButton({	
Name = "英文",
		Callback = function()
loadstring(game:HttpGet("https://raw.githubusercontent.com/why-png/scriptstuffz/master/ninjaleg2", true))()
  end
})
Tab:AddButton({	
Name = "传送",
		Callback = function()
--by Exodi#5973
--vouch me on v3rmillion and enjoy

local MuscleLegends = Instance.new("ScreenGui")
local balls = Instance.new("Frame")
local TextButton = Instance.new("TextButton")
local Frame = Instance.new("Frame")
local TextButton_2 = Instance.new("TextButton")
local MuscleLegends_2 = Instance.new("TextButton")
local Frame_2 = Instance.new("Frame")
local TextButton_3 = Instance.new("TextButton")
local Frame_3 = Instance.new("Frame")
local TextButton_4 = Instance.new("TextButton")
local Frame_4 = Instance.new("Frame")
local TextButton_5 = Instance.new("TextButton")
local Frame_5 = Instance.new("Frame")
local TextButton_6 = Instance.new("TextButton")
local Frame_6 = Instance.new("Frame")


MuscleLegends.Name = "MuscleLegends"
MuscleLegends.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")
MuscleLegends.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

balls.Name = "balls"
balls.Parent = MuscleLegends
balls.BackgroundColor3 = Color3.fromRGB(23, 25, 48)
balls.BorderColor3 = Color3.fromRGB(11, 14, 25)
balls.BorderSizePixel = 6
balls.Position = UDim2.new(0.0587878786, 0, 0.263085395, 0)
balls.Size = UDim2.new(0, 499, 0, 189)

TextButton.Parent = balls
TextButton.BackgroundColor3 = Color3.fromRGB(18, 21, 62)
TextButton.BorderColor3 = Color3.fromRGB(6, 6, 25)
TextButton.BorderSizePixel = 4
TextButton.Position = UDim2.new(0.0237016678, 0, 0.122917295, 0)
TextButton.Size = UDim2.new(0, 140, 0, 51)
TextButton.Font = Enum.Font.Cartoon
TextButton.Text = "Auto Lift"
TextButton.TextColor3 = Color3.fromRGB(211, 183, 81)
TextButton.TextSize = 25.000

Frame.Parent = TextButton
Frame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Frame.BackgroundTransparency = 0.900
Frame.BorderSizePixel = 0
Frame.Position = UDim2.new(-0.00675659161, 0, 0.525454938, 0)
Frame.Size = UDim2.new(0, 140, 0, 23)

TextButton_2.Parent = balls
TextButton_2.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
TextButton_2.BackgroundTransparency = 0.800
TextButton_2.Position = UDim2.new(-0.00193841383, 0, 0.922121644, 0)
TextButton_2.Size = UDim2.new(0, 87, 0, 14)
TextButton_2.Font = Enum.Font.SourceSans
TextButton_2.Text = "Exodi#5973"
TextButton_2.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_2.TextSize = 14.000

MuscleLegends_2.Name = "Muscle Legends"
MuscleLegends_2.Parent = balls
MuscleLegends_2.BackgroundColor3 = Color3.fromRGB(31, 25, 63)
MuscleLegends_2.BorderColor3 = Color3.fromRGB(0, 5, 29)
MuscleLegends_2.BorderSizePixel = 4
MuscleLegends_2.Position = UDim2.new(-0.0147496527, 0, -0.120468944, 0)
MuscleLegends_2.Size = UDim2.new(0, 514, 0, 33)
MuscleLegends_2.Font = Enum.Font.Cartoon
MuscleLegends_2.Text = "Muscle Legends"
MuscleLegends_2.TextColor3 = Color3.fromRGB(234, 199, 0)
MuscleLegends_2.TextSize = 25.000

Frame_2.Parent = MuscleLegends_2
Frame_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Frame_2.BackgroundTransparency = 0.950
Frame_2.BorderSizePixel = 0
Frame_2.Position = UDim2.new(0, 0, 0.515151978, 0)
Frame_2.Size = UDim2.new(0, 513, 0, 15)

TextButton_3.Parent = balls
TextButton_3.BackgroundColor3 = Color3.fromRGB(18, 21, 62)
TextButton_3.BorderColor3 = Color3.fromRGB(6, 6, 25)
TextButton_3.BorderSizePixel = 4
TextButton_3.Position = UDim2.new(0.358371019, 0, 0.122917295, 0)
TextButton_3.Size = UDim2.new(0, 140, 0, 51)
TextButton_3.Font = Enum.Font.Cartoon
TextButton_3.Text = "Legends Gym"
TextButton_3.TextColor3 = Color3.fromRGB(211, 183, 81)
TextButton_3.TextSize = 25.000

Frame_3.Parent = TextButton_3
Frame_3.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Frame_3.BackgroundTransparency = 0.900
Frame_3.BorderSizePixel = 0
Frame_3.Position = UDim2.new(-0.00675659161, 0, 0.525454938, 0)
Frame_3.Size = UDim2.new(0, 140, 0, 23)

TextButton_4.Parent = balls
TextButton_4.BackgroundColor3 = Color3.fromRGB(18, 21, 62)
TextButton_4.BorderColor3 = Color3.fromRGB(6, 6, 25)
TextButton_4.BorderSizePixel = 4
TextButton_4.Position = UDim2.new(0.701056361, 0, 0.122917295, 0)
TextButton_4.Size = UDim2.new(0, 140, 0, 51)
TextButton_4.Font = Enum.Font.Cartoon
TextButton_4.Text = "Anti AFK"
TextButton_4.TextColor3 = Color3.fromRGB(211, 183, 81)
TextButton_4.TextSize = 25.000

Frame_4.Parent = TextButton_4
Frame_4.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Frame_4.BackgroundTransparency = 0.900
Frame_4.BorderSizePixel = 0
Frame_4.Position = UDim2.new(-0.00675659161, 0, 0.525454938, 0)
Frame_4.Size = UDim2.new(0, 140, 0, 23)

TextButton_5.Parent = balls
TextButton_5.BackgroundColor3 = Color3.fromRGB(18, 21, 62)
TextButton_5.BorderColor3 = Color3.fromRGB(6, 6, 25)
TextButton_5.BorderSizePixel = 4
TextButton_5.Position = UDim2.new(0.0237016678, 0, 0.509160638, 0)
TextButton_5.Size = UDim2.new(0, 140, 0, 51)
TextButton_5.Font = Enum.Font.Cartoon
TextButton_5.Text = "Super Speed"
TextButton_5.TextColor3 = Color3.fromRGB(211, 183, 81)
TextButton_5.TextSize = 25.000

Frame_5.Parent = TextButton_5
Frame_5.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Frame_5.BackgroundTransparency = 0.900
Frame_5.BorderSizePixel = 0
Frame_5.Position = UDim2.new(-0.00675659161, 0, 0.525454938, 0)
Frame_5.Size = UDim2.new(0, 140, 0, 23)

TextButton_6.Parent = balls
TextButton_6.BackgroundColor3 = Color3.fromRGB(18, 21, 62)
TextButton_6.BorderColor3 = Color3.fromRGB(6, 6, 25)
TextButton_6.BorderSizePixel = 4
TextButton_6.Position = UDim2.new(0.358371019, 0, 0.509160638, 0)
TextButton_6.Size = UDim2.new(0, 140, 0, 51)
TextButton_6.Font = Enum.Font.Cartoon
TextButton_6.Text = "Auto Rebirth"
TextButton_6.TextColor3 = Color3.fromRGB(211, 183, 81)
TextButton_6.TextSize = 25.000

Frame_6.Parent = TextButton_6
Frame_6.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Frame_6.BackgroundTransparency = 0.900
Frame_6.BorderSizePixel = 0
Frame_6.Position = UDim2.new(-0.00675659161, 0, 0.525454938, 0)
Frame_6.Size = UDim2.new(0, 140, 0, 23)

local function HVDKG_fake_script() -- TextButton.LocalScript 
	local script = Instance.new('LocalScript', TextButton)

	local Button = script.Parent 
	local character = game.Players.LocalPlayer.character
	Button.MouseButton1Click:connect(function()
		while wait() do 
			local args = {
				[1] = "rep"
			}
	
			game:GetService("Players").LocalPlayer.muscleEvent:FireServer(unpack(args))
		end
	
		
	end)
	
end
coroutine.wrap(HVDKG_fake_script)()
local function HFRIPD_fake_script() -- TextButton_3.LocalScript 
	local script = Instance.new('LocalScript', TextButton_3)

	local Button = script.Parent 
	local character = game.Players.LocalPlayer.character
	Button.MouseButton1Click:connect(function()
		game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(4195.27344, 990.221802, -3876.88794, 0.999488235, 5.95610805e-09, -0.0319886059, -4.20918678e-09, 0.99999994, 5.46780257e-08, 0.0319886059, -5.45154073e-08, 0.999488235)
		
		
	end)
	
end
coroutine.wrap(HFRIPD_fake_script)()
local function KYICYI_fake_script() -- TextButton_4.LocalScript 
	local script = Instance.new('LocalScript', TextButton_4)

	local Button = script.Parent 
	local Character = game.Workspace:FindFirstChild(game.Players.LocalPlayer.Name) 
	
	Button.MouseButton1Click:connect(function()
		local vu = game:GetService("VirtualUser")
		game:GetService("Players").LocalPlayer.Idled:connect(function()
			vu:Button2Down(Vector2.new(0,0),workspace.CurrentCamera.CFrame)
			wait(1)
			vu:Button2Up(Vector2.new(0,0),workspace.CurrentCamera.CFrame)
		end)
	end)
	
	
end
coroutine.wrap(KYICYI_fake_script)()
local function GGGSW_fake_script() -- TextButton_5.LocalScript 
	local script = Instance.new('LocalScript', TextButton_5)

	local Button = script.Parent 
	local Character = game.Workspace:FindFirstChild(game.Players.LocalPlayer.Name) 
	
	Button.MouseButton1Click:connect(function()
			Character.Humanoid.WalkSpeed = 100
		
	
	end)
	
	
end
coroutine.wrap(GGGSW_fake_script)()
local function NUOF_fake_script() -- TextButton_6.LocalScript 
	local script = Instance.new('LocalScript', TextButton_6)

	local Button = script.Parent 
	local Character = game.Workspace:FindFirstChild(game.Players.LocalPlayer.Name) 
	
	Button.MouseButton1Click:connect(function()
		while wait() do
			game:GetService("ReplicatedStorage").rEvents.rebirthRemote:InvokeServer()
		end
		
	
	end)
	
	
end
coroutine.wrap(NUOF_fake_script)()
  end
})
Tab:AddButton({	
Name = "改力量",
		Callback = function()
loadstring(game:HttpGet('https://raw.githubusercontent.com/jynzl/main/main/Musclas%20Legenos.lua'))()
  end
})
Tab:AddButton({
	Name = "跟踪玩家",
	Callback = function()
      	loadstring(game:HttpGet("https://pastebin.com/raw/F9PNLcXk"))()
  	end
})
Tab:AddButton({
	Name = "点击传送工具",
	Callback = function()
mouse = game.Players.LocalPlayer:GetMouse() tool = Instance.new("Tool") tool.RequiresHandle = false tool.Name = "[FE] TELEPORT TOOL" tool.Activated:connect(function() local pos = mouse.Hit+Vector3.new(0,2.5,0) pos = CFrame.new(pos.X,pos.Y,pos.Z) game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = pos end) tool.Parent = game.Players.LocalPlayer.Backpack
	end
})
Tab:AddTextbox({
  Name = "移动速度",
  Default = "",
  TextDisappear = true,
  Callback = function(Value)
  game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = Value
  end
})
Tab:AddTextbox({
  Name = "跳跃高度",
   Default = "",
   TextDisappear = true,
   Callback = function(Value)
   game.Players.LocalPlayer.Character.Humanoid.JumpPower = Value
  end
})
local Tab = Window:MakeTab({
    Name = "其他脚本",
    	Icon = "rbxassetid://7734068321",
    		PremiumOnly = false})
Tab:AddButton({	
    Name = "鸡排脚本",
		Callback = function()
--鸡排脚本 必是飞舞
loadstring(game:HttpGet("https://pastebin.com/raw/wVq1jdSQ"))()
  end
})
Tab:AddButton({
	Name = "复制鸡排卡密",
	Callback = function()
     setclipboard("98326")
  	end
})
Tab:AddButton({	
Name = "云脚本",
		Callback = function()
getgenv().XiaoYun="云脚本，作者小云开发改造还次更新"loadstring("\108\111\97\100\115\116\114\105\110\103\40\103\97\109\101\58\72\116\116\112\71\101\116\40\34\104\116\116\112\115\58\47\47\114\97\119\46\103\105\116\104\117\98\117\115\101\114\99\111\110\116\101\110\116\46\99\111\109\47\88\105\97\111\89\117\110\67\78\47\85\87\85\47\109\97\105\110\47\108\108\108\108\108\108\45\45\45\45\45\45\45\45\45\45\45\45\45\45\45\45\45\45\45\45\45\45\45\45\45\45\45\45\45\45\45\45\45\45\108\108\108\108\108\45\45\45\45\45\45\45\45\45\45\45\45\45\45\45\45\45\45\45\45\108\108\108\108\108\46\108\117\97\34\41\41\40\41\10")()
  end
})
Tab:AddButton({
	Name = "波奇塔脚本",
		Callback = function()
--波奇搭小脚本中心"
loadstring(game:HttpGet(utf8.char((function() return table.unpack({104,116,116,112,115,58,47,47,112,97,115,116,101,98,105,110,46,99,111,109,47,114,97,119,47,113,109,55,76,121,119,82,117})end)())))()
    end
})
Tab:AddButton({
	Name = "复制波奇塔脚本卡密",
	Callback = function()
     setclipboard("152439974346918584688166784")
  	end
})
Tab:AddButton({
	Name = "秋·脚本",
		Callback = function()
_G["秋·自制脚本"]="xdjhadgdsrfcyefjhsadcctyseyr6432478rudghfvszhxcaheey"loadstring(game:HttpGet(utf8.char((function() return table.unpack({104,116,116,112,115,58,47,47,112,97,115,116,101,98,105,110,46,99,111,109,47,114,97,119,47,122,110,67,121,54,89,77,81})end)())))()
end
})
Tab:AddButton({
	Name = "秋·脚本卡密",
	Callback = function()
     setclipboard("hydqjb")
  	end
})
Tab:AddButton({
	Name = "USA卡密",
	Callback = function()
     setclipboard("USA AER")
  	end
})
Tab:AddButton({
	Name = "冰脚本",
		Callback = function()
loadstring(game:HttpGet("https://pastebin.com/raw/GR4ChWKv"))
    end
})

Tab:AddButton({
	Name = "冰脚本卡密",
	Callback = function()
     setclipboard("027957")
  	end
})
Tab:AddButton({
	Name = "脚本中心",
		Callback = function()
loadstring(game:HttpGet("\104\116\116\112\115\58\47\47\112\97\115\116\101\98\105\110\46\99\111\109\47\114\97\119\47\103\101\109\120\72\119\65\49"))()
     end
})